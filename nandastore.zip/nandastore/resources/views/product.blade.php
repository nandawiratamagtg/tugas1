@extends('layouts.main')

@section('content')
<div class="container">
    <h3>List product:</h3>
    @foreach ($sepatuposts as $sepatu_post)
    <div class="card mt-3" style="width: 18rem;">
        <img src="{{ $sepatu_post["img"] }}" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">{{ $sepatu_post["tittle"] }}</h5>
          <p class="card-text">{{ $sepatu_post["desc"] }}</p>
          <p class="card-text">Rp: {{ $sepatu_post["price"] }}</p>
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
      </div>
        
    @endforeach
</div>
@endsection
