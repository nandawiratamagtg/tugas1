@extends('layouts.main')

@section('content')
<div class="container">
    <div class="row">
      <div class="col-md-4 offset-md-4 text-center mt-5">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFJ2cM-67BMZ_MwWzpWa7YBmAxN3f-LEcyvhEzOyyN-NpXYFSeMTNIWcXQX8fwIpwJ_EI&usqp=CAU" alt="Profile Picture" class="profile-img">
        <h3 class="mt-3">Nanda Store</h3>
        <p>@sepatu_kekinian</p>
        <p>Toko ini menjual segala macam jenis sepatu dengan kualitas terjamin, pokokne the best semeton mari di order</p>
        <p>WA: 087123987123</p>
      </div>
    </div>
  </div>
  
  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script> 
@endsection