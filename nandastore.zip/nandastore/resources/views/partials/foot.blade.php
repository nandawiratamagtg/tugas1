<footer class="footer bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <p>&copy; 2023 Nanda Store.</p>
        </div>
      </div>
    </div>
  </footer>