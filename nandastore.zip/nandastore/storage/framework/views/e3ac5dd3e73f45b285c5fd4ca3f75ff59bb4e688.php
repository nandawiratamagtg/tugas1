

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>List product:</h3>
    <?php $__currentLoopData = $sepatuposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sepatu_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-3" style="width: 18rem;">
        <img src="<?php echo e($sepatu_post["img"]); ?>" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($sepatu_post["tittle"]); ?></h5>
          <p class="card-text"><?php echo e($sepatu_post["desc"]); ?></p>
          <p class="card-text">Rp: <?php echo e($sepatu_post["price"]); ?></p>
          <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
      </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\app\nandastore\resources\views/product.blade.php ENDPATH**/ ?>