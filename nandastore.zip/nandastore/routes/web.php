<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/products', [ProductController::class, 'index']);


Route::get('/', function () {
    $sepatu_posts = [
        [
            "img" => "https://images.tokopedia.net/img/cache/500-square/VqbcmM/2022/1/25/e0b9467f-2208-48ac-8459-6909b1b77198.jpg?ect=4g",
            "tittle" => "Converse Premium",
            "desc" => "Converse Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere voluptate quidem libero recusandae voluptates sapiente amet cumque iste minima? Laudantium magni beatae ipsam adipisci quo facilis expedita, a atque veniam!",
            "price" => "IDR 50.000"
        ],
        [
            "img" => "https://id-test-11.slatic.net/p/7da3b58c3f79643825a3f1a95810c5e8.jpg",
            "tittle" => "Vans",
            "desc" => "Vans Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere voluptate quidem libero recusandae voluptates sapiente amet cumque iste minima? Laudantium magni beatae ipsam adipisci quo facilis expedita, a atque veniam!",
            "price" => "IDR 150.000"
        ],
        [
            "img" => "https://images.tokopedia.net/img/cache/500-square/VqbcmM/2020/12/7/656cc419-b705-484a-a373-530baa9100c5.jpg",
            "tittle" => "Adidas",
            "desc" => "Adidas Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere voluptate quidem libero recusandae voluptates sapiente amet cumque iste minima? Laudantium magni beatae ipsam adipisci quo facilis expedita, a atque veniam!",
            "price" => "IDR 200.000"
        ],
        ];
    return view('product',[
        "sepatuposts" => $sepatu_posts
    ]);
});

Route::get('/about', function () {
    return view('about');
});
